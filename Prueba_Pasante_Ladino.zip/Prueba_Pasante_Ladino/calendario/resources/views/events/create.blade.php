@extends('layouts.main')

@section('contenido')  
    <div class="container">
        <br>
        <div class="row">
            <div class="cold-md-12">
                <div class="card">
                    <div class="card-header">
                        Crear eventos

                    </div>

                    <div class="card-body">
                        <form action="{{route('events.store')}}" method="POST">
                            @csrf 
                            <div class="form-group">
                                <label for=""> Título</label>
                                <input type="text" class="form-control" name="titulo">                   
                            </div>

                            <div class="form-group">
                                <label for=""> Fecha Inicio</label>
                                <input type="date" maxlength="4" class="form-control" name="fechaInicio" min="1" max="31">                   
                            </div>

                            <div class="form-group">
                                <label for=""> Fecha Fin</label>
                                <input type="date" class="form-control" name="fechaFin" min="1" max="31">                   
                            </div>


                            <br>
                                <button type="submit" class="btn btn-primary">Guardar </button>
                                <a href=" {{ route('events.index')}}" class="btn btn-danger">Cancelar</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection