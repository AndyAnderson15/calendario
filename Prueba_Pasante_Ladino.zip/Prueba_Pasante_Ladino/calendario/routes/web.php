<?php

use Illuminate\Http\Request;
use App\Models\Event;


#LOGIN

Route::middleware('auth')->group(function(){

    Route::get('events', function() {
        $events = Event::orderBy('created_at','desc')->get();
        return view('events.index', compact('events'));
    })->name('events.index');
    
    
    Route::get('events/create', function() {
        return view('events.create');
    })->name('events.create');
    
    
    
    Route::post('events', function(Request $request) {
        $newEvent = new Event;
        $newEvent->titulo= $request->input('titulo');
        $newEvent->fechaInicio= $request->input('fechaInicio');
        $newEvent->fechaFin= $request->input('fechaFin');
        $newEvent->save();
    
        return redirect()->route('events.index')->with('info','Evento creado exitosamente');
    })->name('events.store');
    
    
    Route::delete('events/{id}', function($id) {
        $event = Event::findOrFail($id);
        $event->delete();
        return redirect()->route('events.index')->with('info','Evento eliminado exitosamente');
    })->name('events.destroy');
    
    Route::get('events/{id}/edit', function($id) {
        $event = Event::findOrFail($id);
    
       return view('events.edit',compact('event'));
    })->name('events.edit');
    
    
    Route::put('/events/{id}', function(Request $request, $id) {
        $event = Event::findOrFail($id);
        $event->titulo= $request->input('titulo');
        $event->fechaInicio= $request->input('fechaInicio');
        $event->fechaFin= $request->input('fechaFin');
        $event->save();
    
        return redirect()->route('events.index')->with('info','Evento actualizado exitosamente');
    })->name('events.update');
    
});


Auth::routes();
