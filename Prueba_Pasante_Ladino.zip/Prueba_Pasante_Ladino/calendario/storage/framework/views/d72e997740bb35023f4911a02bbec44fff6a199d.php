

<?php $__env->startSection('contenido'); ?>  
    <div class="container">
        <br>
        <div class="row">
            <div class="cold-md-12">
                <div class="card">
                    <div class="card-header">
                        Crear eventos

                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('events.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?> 
                            <div class="form-group">
                                <label for=""> Título</label>
                                <input type="text" class="form-control" name="titulo">                   
                            </div>

                            <div class="form-group">
                                <label for=""> Fecha Inicio</label>
                                <input type="date" maxlength="4" class="form-control" name="fechaInicio" min="1" max="31">                   
                            </div>

                            <div class="form-group">
                                <label for=""> Fecha Fin</label>
                                <input type="date" class="form-control" name="fechaFin" min="1" max="31">                   
                            </div>


                            <br>
                                <button type="submit" class="btn btn-primary">Guardar </button>
                                <a href=" <?php echo e(route('events.index')); ?>" class="btn btn-danger">Cancelar</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\calendario\resources\views/events/create.blade.php ENDPATH**/ ?>